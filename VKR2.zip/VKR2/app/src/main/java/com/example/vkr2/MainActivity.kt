package com.example.vkr2

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.vkr2.databinding.ActivityMainBinding
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.io.InputStream
import java.nio.FloatBuffer
import kotlin.math.exp

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val IMAGE_PICK_CODE = 1000

    private lateinit var ortEnvironment: OrtEnvironment
    private lateinit var ortSession: OrtSession

    private val classNames = listOf(
        "Apple___Apple_scab", "Apple___Black_rot", "Apple___Cedar_apple_rust", "Apple___healthy",
        "Blueberry___healthy", "Cherry_(including_sour)___Powdery_mildew", "Cherry_(including_sour)___healthy",
        "Corn_(maize)___Cercospora_leaf_spot Gray_leaf_spot", "Corn_(maize)___Common_rust_",
        "Corn_(maize)___Northern_Leaf_Blight", "Corn_(maize)___healthy", "Grape___Black_rot",
        "Grape___Esca_(Black_Measles)", "Grape___Leaf_blight_(Isariopsis_Leaf_Spot)", "Grape___healthy",
        "Orange___Haunglongbing_(Citrus_greening)", "Peach___Bacterial_spot", "Peach___healthy",
        "Pepper,_bell___Bacterial_spot", "Pepper,_bell___healthy", "Potato___Early_blight", "Potato___Late_blight",
        "Potato___healthy", "Raspberry___healthy", "Soybean___healthy", "Squash___Powdery_mildew",
        "Strawberry___Leaf_scorch", "Strawberry___healthy", "Tomato___Bacterial_spot", "Tomato___Early_blight",
        "Tomato___Late_blight", "Tomato___Leaf_Mold", "Tomato___Septoria_leaf_spot",
        "Tomato___Spider_mites Two-spotted_spider_mite", "Tomato___Target_Spot",
        "Tomato___Tomato_Yellow_Leaf_Curl_Virus", "Tomato___Tomato_mosaic_virus", "Tomato___healthy"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initOrt()

        binding.uploadImageButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK)
            intent.type = "image/*"
            startActivityForResult(intent, IMAGE_PICK_CODE)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == IMAGE_PICK_CODE && resultCode == Activity.RESULT_OK) {
            val imageUri = data?.data
            val bitmap = MediaStore.Images.Media.getBitmap(contentResolver, imageUri)
            binding.imageView.setImageBitmap(bitmap)
            classifyImage(bitmap)
        }
    }

    private fun initOrt() {
        ortEnvironment = OrtEnvironment.getEnvironment()
        val modelInputStream: InputStream = assets.open("plant_model.onnx")
        val modelBytes = modelInputStream.readBytes()
        ortSession = ortEnvironment.createSession(modelBytes)
    }

    private fun classifyImage(bitmap: Bitmap) {
        val resizedBitmap = Bitmap.createScaledBitmap(bitmap, 224, 224, true)
        val floatBuffer = preprocessImage(resizedBitmap)

        val shape = longArrayOf(1, 3, 224, 224)
        val inputTensor = OnnxTensor.createTensor(ortEnvironment, floatBuffer, shape)

        val inputName = ortSession.inputNames.iterator().next()
        val result = ortSession.run(mapOf(inputName to inputTensor))
        val output = result[0].value as Array<FloatArray>
        val logits = output[0]

        val predictions = softmax(logits)
        val maxIdx = predictions.indices.maxByOrNull { predictions[it] } ?: -1
        val probability = predictions[maxIdx] * 100

        val resultText = if (maxIdx != -1)
            "${classNames[maxIdx]}\nУверенность: ${"%.2f".format(probability)}%"
        else
            "Ошибка классификации"

        binding.resultText.text = resultText
    }

    private fun softmax(logits: FloatArray): FloatArray {
        val maxLogit = logits.maxOrNull() ?: 0f
        val expValues = logits.map { exp((it - maxLogit).toDouble()) }
        val sumExp = expValues.sum()
        return expValues.map { (it / sumExp).toFloat() }.toFloatArray()
    }

    private fun preprocessImage(bitmap: Bitmap): FloatBuffer {
        val floatBuffer = FloatBuffer.allocate(3 * 224 * 224)
        val mean = floatArrayOf(0.485f, 0.456f, 0.406f)
        val std = floatArrayOf(0.229f, 0.224f, 0.225f)

        for (channel in 0..2) {
            for (y in 0 until 224) {
                for (x in 0 until 224) {
                    val pixel = bitmap.getPixel(x, y)
                    val value = when (channel) {
                        0 -> (Color.red(pixel) / 255.0f - mean[0]) / std[0] // R
                        1 -> (Color.green(pixel) / 255.0f - mean[1]) / std[1] // G
                        else -> (Color.blue(pixel) / 255.0f - mean[2]) / std[2] // B
                    }
                    floatBuffer.put(value)
                }
            }
        }

        floatBuffer.rewind()
        return floatBuffer
    }
}
